```markdown
# Sistema de Design: Imersão Hiper-Tecnológica e Progressão Gamificada

Este documento estabelece as diretrizes visuais e estruturais para a criação de uma experiência de vendas de alto impacto. O foco não é apenas informar, mas conduzir o usuário através de uma jornada de evolução, utilizando metáforas visuais de interfaces de jogos modernos (HUDs) e profundidade tridimensional.

## 1. Estrela do Norte Criativa: "O HUD Evolutivo"

A Estrela do Norte deste sistema de design é o conceito de **HUD Evolutivo (Heads-Up Display)**. Diferente de sites estáticos, a interface deve parecer um sistema operacional avançado ou o menu de um jogo AAA. 

A quebra do "aspecto de template" é alcançada através de:
- **Assimetria Intencional:** Elementos de interface flutuantes que não se alinham perfeitamente à grade rígida, sugerindo movimento.
- **Sobreposição de Camadas:** Uso intenso de Glassmorphism para criar a sensação de que a interface está "flutuando" sobre o motor de renderização do jogo.
- **Layout Centralizado 100%:** A ausência de bordas laterais foca a energia no centro da tela, criando um túnel de atenção para a conversão.

## 2. Cores e Atmosfera

O sistema utiliza uma base ultra-escura (`surface`) para permitir que os acentos neon "vibrem" com intensidade máxima, simulando emissão de luz.

### A Regra "No-Line" (Sem Linhas)
Está terminantemente proibido o uso de bordas sólidas de 1px para separar seções. A distinção entre áreas deve ser feita exclusivamente por:
1.  **Transições de Tom:** Uma seção em `surface` movendo-se para uma seção em `surface-container-low`.
2.  **Gradients de Assinatura:** Uso de `primary` para `primary-container` em áreas de destaque para dar "alma" e profundidade.

### Hierarquia de Superfícies (Nesting)
Tratamos a UI como camadas físicas de vidro fosco:
- **Fundo Base:** `surface` (#0e0e13).
- **Cartões de Nível 1:** `surface-container-low` (#131318).
- **Elementos de Interação:** `surface-container-high` (#1f1f26).
- **Glassmorphism:** Use `surface-bright` com 40% de opacidade e `backdrop-blur` de 20px para elementos que exigem foco imediato.

## 3. Tipografia Editorial Tech

A tipografia é o motor da autoridade. Combinamos a rigidez geométrica do **Space Grotesk** com a legibilidade humana da **Manrope**.

*   **Display (Space Grotesk):** Utilizada para promessas de vendas e grandes marcos de "Level Up". O tamanho `display-lg` (3.5rem) deve ser usado com `letter-spacing` negativo para um visual editorial premium.
*   **Headlines (Space Grotesk):** Para subseções, use `headline-lg`. A tipografia aqui deve ser tratada como um elemento gráfico, muitas vezes em *Uppercase* para evocar a estética de interfaces militares/tech.
*   **Body (Manrope):** O corpo do texto (`body-lg`) prioriza o conforto visual. A fonte Manrope suaviza a agressividade dos neons, trazendo confiança e clareza.

## 4. Elevação, Profundidade e o "Efeito 3D"

A profundidade não é um ornamento, é uma ferramenta de hierarquia.

*   **Camadas Tonais:** Em vez de sombras pesadas, empilhe containers. Um cartão `surface-container-highest` sobre um fundo `surface-dim` cria uma elevação natural e sofisticada.
*   **Sombras Ambientes:** Quando um elemento flutua (ex: um botão 3D), use sombras ultra-difusas. A cor da sombra deve ser uma versão tingida de `primary` (azul elétrico) ou `tertiary` (roxo) com apenas 5% de opacidade, simulando o brilho que o objeto projeta na superfície abaixo.
*   **Ghost Borders:** Se for necessária uma borda por acessibilidade, utilize o token `outline-variant` com 15% de opacidade. Bordas 100% opacas são proibidas por quebrarem a imersão tecnológica.

## 5. Componentes de Interface de Jogo

### Botões 3D (Core Interaction)
Os botões não são planos. Eles possuem "espessura" (Z-axis).
- **Estado Normal:** Gradiente de `primary` para `primary-dim` com um chanfro simulado no topo (borda superior levemente mais clara).
- **Hover:** O botão deve "afundar" levemente (transform: translateY(2px)) e aumentar a intensidade do brilho externo (Glow).
- **Border-radius:** Use o padrão `md` (0.75rem) para um equilíbrio entre o orgânico e o tecnológico.

### Barras de Progresso Animadas
Essenciais para a gamificação da página de vendas.
- **Track:** `surface-container-highest`.
- **Fill:** Gradiente linear de `secondary` (cyber green) para `primary` (electric blue).
- **Micro-interação:** Um brilho (glow) que percorre a barra periodicamente para indicar que o sistema está "carregando" a evolução do usuário.

### Cards de Profundidade (Depth Cards)
- **Regra de Divisores:** É proibido o uso de linhas divisoras. Utilize o escalonamento de espaçamento (Spacing Scale `8` ou `12`) ou mudanças sutis no tom de fundo do card para separar o conteúdo.
- **Conteúdo:** Títulos em `title-lg` (Manrope) com ícones em 3D renderizados ou glifos neon.

### Badges de Nível (Leveling Chips)
- Utilizam o token `tertiary` (#d873ff) para indicar status especiais ou bônus. Devem ter um aspecto de "vidro luminoso" com bordas arredondadas `full`.

## 6. Do's and Don'ts (Práticas Recomendadas)

**Sim (Do):**
- Use o espaçamento `16` (5.5rem) entre grandes seções para permitir que os elementos 3D "respirem".
- Aplique `text-shadow` muito sutil em títulos `display` para simular brilho de tela (CRT/Neon).
- Centralize todo o conteúdo principal, permitindo que elementos decorativos de UI (pequenos códigos, coordenadas, linhas de grid sutis) sangrem para as laterais.

**Não (Don't):**
- Nunca use preto puro (#000) para fundos, a menos que seja o `surface-container-lowest` para contraste extremo. Use o `surface` (#0e0e13) para manter a profundidade.
- Não use sombras pretas genéricas. Sombras devem ser coloridas de acordo com a luz ambiente do componente.
- Evite alinhar textos longos à direita; a legibilidade em uma página de vendas gamificada depende da ancoragem central ou à esquerda dentro de blocos centralizados.

---
*Este sistema de design deve ser aplicado com rigor técnico para garantir que a interface pareça um produto de engenharia de software de elite, e não apenas um site de vendas comum.*```